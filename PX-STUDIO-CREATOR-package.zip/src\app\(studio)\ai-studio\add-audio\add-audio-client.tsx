﻿"use client";
import { useEffect, useState } from "react";
import { Card, Button, Input, Select } from "@/components/ui";
import { Upload, Music, Download, Film } from "lucide-react";

type AudioAsset = { id: string; name: string; format?: string; duration?: number | null; fileUrl?: string };

export default function AddAudioClient() {
  const [video, setVideo] = useState<File | null>(null);
  const [audio, setAudio] = useState<File | null>(null);
  const [audioAssetId, setAudioAssetId] = useState("");
  const [library, setLibrary] = useState<AudioAsset[]>([]);
  const [mode, setMode] = useState("mix");
  const [musicVolume, setMusicVolume] = useState("1");
  const [originalVolume, setOriginalVolume] = useState("0.8");
  const [name, setName] = useState("Video dengan Suara");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/audio/library", { cache: "no-store" });
        const j = await res.json().catch(() => ({}));
        if (Array.isArray(j.items)) setLibrary(j.items);
        else if (Array.isArray(j.assets)) setLibrary(j.assets);
      } catch {}
    })();
  }, []);

  async function submit() {
    if (!video) { setError("Pilih file video terlebih dahulu."); return; }
    if (!audio && !audioAssetId) { setError("Pilih/unggah file audio atau pilih dari Audio Library."); return; }
    setBusy(true); setError(null); setResult(null);
    try {
      const fd = new FormData();
      fd.append("video", video);
      if (audio) fd.append("audio", audio);
      if (!audio && audioAssetId) fd.append("audioAssetId", audioAssetId);
      fd.append("mode", mode);
      fd.append("musicVolume", musicVolume);
      fd.append("originalVolume", originalVolume);
      fd.append("name", name);
      const res = await fetch("/api/tools/mix-audio", { method: "POST", body: fd });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || "Gagal memproses video");
      setResult(j);
    } catch (e: any) {
      setError(e.message || "Gagal memproses video");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid xl:grid-cols-[1.1fr_.9fr] gap-6 lg:gap-8 items-start">
      <Card className="p-5 sm:p-6 space-y-5">
        {error && <div className="rounded-xl border border-red-500/20 bg-red-500/10 text-red-300 text-sm px-4 py-3">{error}</div>}

        <div className="space-y-2">
          <label className="text-sm text-zinc-300">1. Video</label>
          <div className="rounded-xl border border-dashed border-white/15 bg-white/[0.02] p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm text-zinc-300"><Film size={16} className="text-violet-300"/> {video ? video.name : "Belum ada video dipilih"}</div>
            <Input type="file" accept="video/mp4,video/webm,video/quicktime,video/x-matroska,.mkv" onChange={e => setVideo(e.target.files?.[0] || null)} />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-zinc-300">2. Suara / Musik</label>
          <div className="rounded-xl border border-dashed border-white/15 bg-white/[0.02] p-4 space-y-3">
            <div className="space-y-2">
              <div className="text-xs text-zinc-400">Upload audio</div>
              <Input type="file" accept="audio/*,video/mp4" onChange={e => { setAudio(e.target.files?.[0] || null); if (e.target.files?.[0]) setAudioAssetId(""); }} />
            </div>
            <div className="text-xs text-zinc-500 text-center">atau</div>
            <div className="space-y-2">
              <div className="text-xs text-zinc-400">Pilih dari Audio Library</div>
              <Select value={audioAssetId} onChange={e => { setAudioAssetId(e.target.value); if (e.target.value) setAudio(null); }}>
                <option value="">-- Pilih audio --</option>
                {library.map(a => <option key={a.id} value={a.id}>{a.name}{a.format ? ` (${a.format})` : ""}</option>)}
              </Select>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2 sm:col-span-2"><label className="text-sm text-zinc-300">Mode Audio</label>
            <Select value={mode} onChange={e=>setMode(e.target.value)}>
              <option value="mix">Mix (gabung dengan audio asli video)</option>
              <option value="replace">Replace (ganti audio asli dengan audio baru)</option>
              <option value="music">Music Only (gunakan audio baru)</option>
            </Select>
          </div>
          <div className="space-y-2"><label className="text-sm text-zinc-300">Volume Audio Asli</label><Input type="number" min={0} max={2} step="0.1" value={originalVolume} onChange={e=>setOriginalVolume(e.target.value)} disabled={mode !== "mix"} /></div>
          <div className="space-y-2"><label className="text-sm text-zinc-300">Volume Audio/Musik Baru</label><Input type="number" min={0} max={2} step="0.1" value={musicVolume} onChange={e=>setMusicVolume(e.target.value)} /></div>
          <div className="space-y-2 sm:col-span-2"><label className="text-sm text-zinc-300">Nama Output</label><Input value={name} onChange={e=>setName(e.target.value)} /></div>
        </div>

        <Button className="w-full" onClick={submit} disabled={busy || !video || (!audio && !audioAssetId)}><Music size={16}/> {busy ? "Memproses & Merender..." : "Tambahkan Suara & Render Video"}</Button>
        <div className="text-xs text-zinc-500">Durasi output mengikuti video (audio akan menyesuaikan/loop jika lebih pendek, dipotong jika lebih panjang). Proses menggunakan FFmpeg.</div>
      </Card>

      <Card className="p-5 sm:p-6 space-y-4">
        <div className="font-medium">Hasil</div>
        {!result ? <div className="text-sm text-zinc-500 py-8 text-center">Belum ada hasil. Unggah video & audio lalu klik render.</div> : (
          <div className="space-y-4">
            <div className="aspect-video bg-black/50 rounded-xl overflow-hidden border border-white/10">
              {result.fileUrl ? <video src={result.fileUrl} controls className="w-full h-full object-contain" /> : null}
            </div>
            <div className="text-sm text-zinc-400 space-y-1">
              {result.duration != null && <div>Durasi: <span className="text-zinc-200">{Number(result.duration).toFixed(2)}s</span></div>}
              {result.fileSize != null && <div>Ukuran: <span className="text-zinc-200">{(result.fileSize/1024/1024).toFixed(2)} MB</span></div>}
            </div>
            {result.fileUrl && <a href={result.fileUrl} download className="inline-flex w-full"><Button variant="secondary" className="w-full"><Download size={16}/> Download MP4</Button></a>}
          </div>
        )}
      </Card>
    </div>
  );
}
