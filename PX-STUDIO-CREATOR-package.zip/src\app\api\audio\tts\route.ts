﻿import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs/promises";
import os from "os";
import crypto from "crypto";
import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { STORAGE_ROOT } from "@/lib/storage";
import { synthesizeSpeechWithTask } from "@/lib/ai-providers";
import { probeVideo, runProcess } from "@/lib/ffmpeg";

export const runtime = "nodejs";

function safeName(s: string) { return String(s || "tts-audio").replace(/[^a-zA-Z0-9._-]+/g, "_").slice(0, 80) || "tts-audio"; }

type LocalVoice = { name: string; culture: string; gender: string; language: string };

function parseVoicesOutput(out: string): LocalVoice[] {
  return String(out || "")
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(Boolean)
    .map(l => {
      const [name, culture, gender] = l.split("|");
      const c = (culture || "").trim();
      const lang = c.toLowerCase().startsWith("id") ? "id" : c.toLowerCase().startsWith("en") ? "en" : (c || "unknown");
      return { name: (name || "").trim(), culture: c, gender: (gender || "").trim(), language: lang };
    })
    .filter(v => v.name);
}

async function listLocalVoices(): Promise<LocalVoice[]> {
  if (process.platform !== "win32") return [];
  const script = [
    "Add-Type -AssemblyName System.Speech;",
    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;",
    "$s.GetInstalledVoices() | ForEach-Object { $v=$_.VoiceInfo; Write-Output ($v.Name + '|' + $v.Culture.Name + '|' + $v.Gender.ToString()) }"
  ].join(" ");
  const ps = await runProcess("powershell", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script]);
  if (ps.code !== 0) return [];
  return parseVoicesOutput(ps.stdout || "");
}

function pickLocalVoice(voices: LocalVoice[], requested?: string | null): { voice: LocalVoice | null; reason?: string } {
  if (!voices.length) return { voice: null, reason: "Tidak ada voice TTS lokal yang terpasang." };
  const req = String(requested || "").trim();
  if (req && req !== "auto" && req !== "auto-id" && req !== "auto-en") {
    const exact = voices.find(v => v.name === req);
    if (exact) return { voice: exact };
  }
  // Prefer Indonesian for fluent Indonesian fallback
  const idVoice = voices.find(v => v.culture.toLowerCase().startsWith("id") || /indones/i.test(v.name));
  if (req === "auto-en") {
    const en = voices.find(v => v.culture.toLowerCase().startsWith("en")) || voices[0];
    return { voice: en };
  }
  if (idVoice) return { voice: idVoice };
  // No Indonesian voice installed; pick first available but warn
  const en = voices.find(v => v.culture.toLowerCase().startsWith("en")) || voices[0];
  return { voice: en, reason: "Voice Bahasa Indonesia tidak terpasang di Windows ini, fallback memakai voice tersedia (mungkin kurang lancar untuk teks Indonesia)." };
}

function psQuoteLiteral(s: string) {
  return "'" + String(s).replace(/'/g, "''") + "'";
}

async function synthesizeLocalTTS(text: string, format: "mp3" | "wav", requestedVoice?: string | null): Promise<{ buffer: Buffer; contentType: string; fallback: true; note: string; voiceUsed?: string | null }> {
  if (process.platform !== "win32") {
    throw new Error("Local TTS fallback hanya tersedia di Windows pada instalasi ini.");
  }
  const voices = await listLocalVoices();
  const picked = pickLocalVoice(voices, requestedVoice);
  const voiceName = picked.voice?.name || null;

  const tmpBase = path.join(os.tmpdir(), `px-tts-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`);
  const txtPath = `${tmpBase}.txt`;
  const wavPath = `${tmpBase}.wav`;
  const outPath = format === "mp3" ? `${tmpBase}.mp3` : wavPath;
  try {
    await fs.writeFile(txtPath, text, "utf8");
    const psLines = [
      "$ErrorActionPreference='Stop';",
      "Add-Type -AssemblyName System.Speech;",
      "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;",
    ];
    if (voiceName) psLines.push(`try { $s.SelectVoice(${psQuoteLiteral(voiceName)}); } catch {}`);
    psLines.push(
      `$t = Get-Content -LiteralPath ${psQuoteLiteral(txtPath)} -Raw -Encoding UTF8;`,
      `$s.SetOutputToWaveFile(${psQuoteLiteral(wavPath)});`,
      "$s.Rate = 0;",
      "$s.Speak($t);",
      "$s.Dispose();"
    );
    const ps = await runProcess("powershell", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", psLines.join(" ")]);
    if (ps.code !== 0) {
      throw new Error((ps.stderr || ps.stdout || "Local TTS failed").slice(-400));
    }
    let finalPath = wavPath;
    if (format === "mp3") {
      const ff = process.env.FFMPEG_PATH || "ffmpeg";
      const conv = await runProcess(ff, ["-y", "-i", wavPath, "-c:a", "libmp3lame", "-b:a", "192k", outPath]);
      if (conv.code === 0) finalPath = outPath;
      else finalPath = wavPath;
    }
    const buffer = await fs.readFile(finalPath);
    const actualFormat = finalPath.endsWith(".mp3") ? "mp3" : "wav";
    const notes = ["Menggunakan fallback TTS lokal (Windows)."];
    if (voiceName) notes.push(`Suara: ${voiceName}${picked.voice?.culture ? ` (${picked.voice.culture})` : ""}.`);
    if (picked.reason) notes.push(picked.reason);
    return { buffer, contentType: actualFormat === "mp3" ? "audio/mpeg" : "audio/wav", fallback: true, note: notes.join(" "), voiceUsed: voiceName };
  } finally {
    await Promise.allSettled([txtPath, wavPath, `${tmpBase}.mp3`].map(p => fs.unlink(p).catch(() => {})));
  }
}

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const voices = await listLocalVoices();
    const hasIndonesian = voices.some(v => v.culture.toLowerCase().startsWith("id") || /indones/i.test(v.name));
    return NextResponse.json({ ok: true, localVoices: voices, hasIndonesianVoice: hasIndonesian, localFallbackAvailable: process.platform === "win32" });
  } catch (e: any) {
    return NextResponse.json({ ok: false, localVoices: [], error: e?.message || "Failed" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const body = await req.json().catch(() => ({}));
    const text = String(body.text || "").trim();
    const voice = String(body.voice || "alloy");
    const localVoice = body.localVoice ? String(body.localVoice) : (body.voice || null);
    const format = (String(body.format || "mp3").toLowerCase() === "wav" ? "wav" : "mp3") as "mp3" | "wav";
    const model = body.model ? String(body.model) : undefined;
    const name = String(body.name || "Text to Speech");
    const saveToLibrary = body.saveToLibrary !== false;
    if (!text) return NextResponse.json({ error: "Text is required" }, { status: 400 });

    let buffer: Buffer;
    let usedFallback = false;
    let note: string | null = null;
    let voiceUsed: string | null = null;
    try {
      const ai = await synthesizeSpeechWithTask("text_to_speech", text, { voice, format, model });
      buffer = Buffer.from(ai.buffer);
    } catch (aiErr: any) {
      try {
        const local = await synthesizeLocalTTS(text, format, localVoice);
        buffer = local.buffer;
        usedFallback = true;
        note = local.note;
        voiceUsed = local.voiceUsed || null;
      } catch (localErr: any) {
        const aiMsg = aiErr?.message || "AI TTS failed";
        const localMsg = localErr?.message || "Local TTS fallback failed";
        throw new Error(`${aiMsg} (fallback lokal gagal: ${localMsg})`);
      }
    }

    const outDir = path.join(STORAGE_ROOT, "audio", user.id);
    await fs.mkdir(outDir, { recursive: true });
    const outPath = path.join(outDir, `${Date.now()}-${safeName(name)}.${format}`);
    let finalFormat = format;
    if (format === "mp3" && buffer.slice(0,4).toString("ascii") === "RIFF") {
      finalFormat = "wav";
    }
    const finalOutPath = finalFormat === format ? outPath : outPath.replace(/\.mp3$/i, ".wav");
    await fs.writeFile(finalOutPath, buffer);

    let duration: number | null = null;
    try { duration = (await probeVideo(finalOutPath)).duration || null; } catch {}
    const st = await fs.stat(finalOutPath).catch(() => null);

    let asset: any = null;
    if (saveToLibrary) {
      asset = await prisma.audioAsset.create({ data: { userId: user.id, name, format: finalFormat, filePath: finalOutPath, duration, fileSize: st?.size || null, sourceName: usedFallback ? "Text-to-Speech (Local Fallback)" : "Text-to-Speech" } });
    }

    const rel = path.relative(STORAGE_ROOT, finalOutPath).replace(/\\/g, "/");
    return NextResponse.json({ ok: true, asset, fileUrl: `/api/files?path=${encodeURIComponent(rel)}`, duration, fileSize: st?.size || null, format: finalFormat, fallback: usedFallback, note, voiceUsed });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "Text-to-speech failed" }, { status: 500 });
  }
}
