import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs/promises";
import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { runProcess } from "@/lib/ffmpeg";
import { clipsDir, tempDir, ensureProjectDirs, STORAGE_ROOT } from "@/lib/storage";
import { transcribeWithTask } from "@/lib/ai-providers";
import { transcriptToSrt } from "@/lib/captions";

function toDownloadUrl(absPath: string | null) {
  if (!absPath) return null;
  const rel = path.relative(STORAGE_ROOT, absPath).replace(/\\/g, "/");
  if (!rel || rel.startsWith("..")) return null;
  return `/api/files?path=${encodeURIComponent(rel)}`;
}

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string; clipId: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id, clipId } = await params;
    const project = await prisma.project.findUnique({ where: { id } });
    if (!project || project.userId !== user.id) return NextResponse.json({ error: "Project not found" }, { status: 404 });
    const clip = await prisma.clip.findUnique({ where: { id: clipId } });
    if (!clip || clip.projectId !== project.id) return NextResponse.json({ error: "Clip not found" }, { status: 404 });

    await ensureProjectDirs(project.id);
    const input = (clip.outputPath && clip.status === "completed") ? clip.outputPath : project.sourcePath;
    if (!input) return NextResponse.json({ error: "No media source available for transcription" }, { status: 400 });

    const work = tempDir(project.id);
    await fs.mkdir(work, { recursive: true });
    const wavPath = path.join(work, `caption-${clip.id}-${Date.now()}.wav`);

    // extract audio (trim to clip segment when using source video)
    const ffmpeg = process.env.FFMPEG_PATH || "ffmpeg";
    const args: string[] = ["-y"];
    if (input === project.sourcePath) {
      const start = Math.max(0, Number(clip.startTime || 0));
      const dur = Math.max(0.2, Number(clip.duration || (Number(clip.endTime || 0) - start) || 0));
      if (start > 0) args.push("-ss", String(start));
      args.push("-i", input, "-t", String(dur));
    } else {
      args.push("-i", input);
    }
    args.push("-vn", "-ac", "1", "-ar", "16000", "-f", "wav", wavPath);
    const { code, stderr } = await runProcess(ffmpeg, args);
    if (code !== 0) throw new Error(`Audio extraction failed: ${String(stderr || "").slice(-400)}`);

    const transcript = await transcribeWithTask("speech_to_text", wavPath);
    const srt = transcriptToSrt(transcript, Number(clip.duration || 10));
    if (!srt.trim()) throw new Error("Transcription returned empty caption text");

    const outDir = clipsDir(project.id);
    await fs.mkdir(outDir, { recursive: true });
    const srtPath = path.join(outDir, `${clip.id}.srt`);
    await fs.writeFile(srtPath, srt, "utf8");
    await prisma.clip.update({ where: { id: clip.id }, data: { subtitlePath: srtPath } });

    await fs.unlink(wavPath).catch(() => {});
    return NextResponse.json({ ok: true, subtitlePath: srtPath, subtitleUrl: toDownloadUrl(srtPath), text: transcript?.text || null });
  } catch (e: any) {
    const msg = e?.name === "AbortError" ? "Timeout" : (e?.message || "Failed to generate captions");
    return NextResponse.json({ ok: false, error: msg }, { status: 500 });
  }
}
